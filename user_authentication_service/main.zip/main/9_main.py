#!/usr/bin/env python3
"""
Main file to test Task 9: Generate UUIDs
"""
from auth import _generate_uuid

if __name__ == "__main__":
    # Generate a few UUIDs and print them
    print(_generate_uuid())
    print(_generate_uuid())
